package com.vti.backend.businesslayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.entity.Employee;
import com.vti.entity.Manager;

public interface IUsersServices {
	List<Employee> getEmployeesByProjectId(Integer projectId) throws SQLException;
	boolean isProjectIdExists(Integer projectId) throws ClassNotFoundException, SQLException;
	
	List<Manager> getManagerByProjectId(Integer projectId) throws SQLException;
}
