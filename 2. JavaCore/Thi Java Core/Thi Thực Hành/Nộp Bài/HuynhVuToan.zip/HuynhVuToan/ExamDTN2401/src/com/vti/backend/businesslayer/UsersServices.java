package com.vti.backend.businesslayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.backend.datalayer.UsersRepository;
import com.vti.entity.Employee;
import com.vti.entity.Manager;
import com.vti.backend.datalayer.IUsersRepository;

public class UsersServices implements IUsersServices {
	private IUsersRepository usersRepository;
	
	public UsersServices() {
		usersRepository = new UsersRepository();
	}

	@Override
	public List<Employee> getEmployeesByProjectId(Integer projectId) throws SQLException {
		return usersRepository.getEmployeesByProjectId(projectId);
	}

	@Override
	public boolean isProjectIdExists(Integer projectId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return usersRepository.isProjectIdExists(projectId);
	}

	@Override
	public List<Manager> getManagerByProjectId(Integer projectId) throws SQLException {
		// TODO Auto-generated method stub
		return usersRepository.getManagerByProjectId(projectId);
	}

	
	
	
}
