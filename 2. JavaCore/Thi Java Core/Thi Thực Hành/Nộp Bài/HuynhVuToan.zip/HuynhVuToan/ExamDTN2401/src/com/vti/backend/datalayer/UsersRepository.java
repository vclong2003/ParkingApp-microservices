package com.vti.backend.datalayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vti.backend.utils.JDBCUtils;
import com.vti.entity.Employee;
import com.vti.entity.Employee.ProSkill;
import com.vti.entity.Manager;
import com.vti.entity.User.Role;

public class UsersRepository implements IUsersRepository {
	
	private JDBCUtils jdbcUtils;

	public UsersRepository() {
		jdbcUtils = new JDBCUtils();
	}
	
	public boolean isProjectIdExists(Integer projectId) throws ClassNotFoundException, SQLException {
		
		String sql = "select * from `users` where project_id = ?";
		
		Connection connection = jdbcUtils.getConnection();
		PreparedStatement pstm = connection.prepareStatement(sql);
		pstm.setInt(1, projectId);

		
		ResultSet resultSet = pstm.executeQuery();

		
		if (resultSet.next()) {
			
			jdbcUtils.closeConnection(connection, resultSet, pstm, null);
			return true;
		} else {
			jdbcUtils.closeConnection(connection, resultSet, pstm, null);
			return false;
		}
	}
	
	public List<Employee> getEmployeesByProjectId(Integer projectId) throws SQLException {
        List<Employee> employees = new ArrayList<>();
        
        String sql = "SELECT * FROM users WHERE project_id = ? AND role = 'EMPLOYEE'";
        
        Connection connection = jdbcUtils.getConnection();
        PreparedStatement pstm = connection.prepareStatement(sql);
		pstm.setInt(1, projectId);
		
		ResultSet rs = pstm.executeQuery();
		
		while (rs.next()) {
			ProSkill pk;
			if (rs.getString("pro_skill").equals(ProSkill.PHP)) {
				pk = ProSkill.PHP;
			} else if (rs.getString("pro_skill").equals(ProSkill.JAVA)) {
				pk = ProSkill.JAVA;
			} else if (rs.getString("pro_skill").equals(ProSkill.PYTHON)) {
				pk = ProSkill.PYTHON;
			} else {
				pk = ProSkill.TEST;
			}
			Employee emp = new Employee(rs.getInt("id"), rs.getString("full_name"), 
					rs.getString("email"),projectId, Role.EMPLOYEE, pk );
			employees.add(emp);
		}
		return employees;
        
  }
	public List<Manager> getManagerByProjectId(Integer projectId) throws SQLException {
        List<Manager> managers = new ArrayList<>();
        
        String sql = "SELECT * FROM users WHERE project_id = ? AND role = 'MANAGER'";
        
        Connection connection = jdbcUtils.getConnection();
        PreparedStatement pstm = connection.prepareStatement(sql);
		pstm.setInt(1, projectId);
		
		ResultSet rs = pstm.executeQuery();
		while(rs.next()) {
			Manager mng = new Manager(rs.getInt("id"), rs.getString("full_name"), 
					rs.getString("email"), projectId,Role.MANAGER, rs.getByte("exp_in_year") );
			managers.add(mng);
		}

		
		jdbcUtils.closeConnection(connection, rs, pstm, null);
		
		return managers;
        
  }

}

