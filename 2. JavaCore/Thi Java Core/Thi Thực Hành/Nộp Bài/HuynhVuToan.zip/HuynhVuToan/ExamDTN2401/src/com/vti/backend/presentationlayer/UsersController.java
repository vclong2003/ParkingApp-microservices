package com.vti.backend.presentationlayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.backend.businesslayer.IUsersServices;
import com.vti.backend.businesslayer.UsersServices;
import com.vti.entity.Employee;
import com.vti.entity.Manager;

public class UsersController {
	
	public IUsersServices usersServices;
	public UsersController() {
		
		usersServices = new UsersServices();
	}
	

	public List<Employee> getEmployeesByProjectId(int projectId) throws SQLException {
		// TODO Auto-generated method stub
		return usersServices.getEmployeesByProjectId(projectId);
	}
	public boolean isProjectIdExists(Integer projectId) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return usersServices.isProjectIdExists(projectId);
	}
	public List<Manager> getManagerByProjectId(Integer projectId) throws SQLException {
		// TODO Auto-generated method stub
		return usersServices.getManagerByProjectId(projectId);
}
}