package com.vti.backend.utils;

import java.util.Scanner;

public class ScannerUtil {
    private static final Scanner SCANNER = new Scanner(System.in);

    public static String inputString() {
        return SCANNER.nextLine()
                .trim()
                .replaceAll("\\s+}", " ");
    }

    public static int inputInt() {
        while (true) {
            try {
                String input = inputString();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.err.println("Yeu cau nhap vao mot so nguyen.");
                System.err.println("Nhap lai.");
            }
        }
    }

    public static String inputEmail() {
        while (true) {
            String input = inputString();
            if (input.contains("@")) {
                return input;
            } else {
                System.err.println("Email phai chua ky tu @");
                System.err.println("Nhap lai!");
            }
        }
    }

    public static String inputFullName() {
        while (true) {
            String input = inputString();
            if (hasAllAlphabeticCharacters(input)) {
                return input;
            } else {
                System.err.println("Full name chi chua chu, ko chua bat ky ki tu dac biet nao");
                System.err.println("Nhap lai!");
            }
        }
    }

    private static boolean hasAllAlphabeticCharacters(String s) {
        int length = s.length();
        for (int i = 0; i < length; i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c))
                continue;
            if (!Character.isAlphabetic(c))
                return false;
        }
        return true;
    }

    public static String inputPassword() {
        while (true) {
            String input = inputString();
            int length = input.length();
            if (length < 6 || length > 12) {
                System.out.println("Password phai co do dai tu 6 - 12 ky tu");
                System.out.println("NHap lai!"); 
            } else {
                return input;
            }
        }

    }
    public static int inputId(String msg) {
		while (true) {
			System.out.println(msg);
			int id = inputInt();
			if (id > 0) {
				return id;
			}
			// else
			System.out.println("Please input a id as int which must be greater than > 0, please input again.");
		}
	}
}