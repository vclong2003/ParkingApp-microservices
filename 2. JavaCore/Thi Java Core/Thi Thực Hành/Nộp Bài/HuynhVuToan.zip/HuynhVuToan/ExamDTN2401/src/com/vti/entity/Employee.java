package com.vti.entity;

public class Employee extends User {
	public enum ProSkill {
		PHP,TEST,JAVA,PYTHON
	}
	private ProSkill proSkill;
	
	
	
		
	public Employee(int id, String fullName, String email, Integer projectId, Role role, ProSkill proSkill) {
		super(id, fullName, email, projectId, role);
		this.proSkill = proSkill;
	}
	
	public ProSkill getProSkill() {
		return proSkill;
	}
	public void setProSkill(ProSkill proSkill) {
		this.proSkill = proSkill;
	}
	
	
	

}
