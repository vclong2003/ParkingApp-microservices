package com.vti.frontend;

import com.vti.backend.utils.ScannerUtil;

public class Menu {
	public static void main(String[] args) {
		int choice = -1;
		while (true) {
			menu();
			choice = ScannerUtil.inputInt();

			switch (choice) {
			case 1:
//				chuc nang login
				break;
			case 2:
				UserFunction.getAllEmployeeByProjectId();
				break;
			case 3:
				UserFunction.getAllManagerByProjectId();
				break;
			case 4:
				System.out.println("Hẹn gặp lại");
				return;
			default:
				System.out.println("Vui lòng nhập lại!");
			}
		}
	}

	public static void menu() {
		System.out.println("\n==================================Manage User===============================");
	
		System.out.println( "1. Đăng nhập vào Manager");
		System.out.println( "2. Lấy danh sách Employee bằng project ID");
		System.out.println( "3. Lấy danh sách Manager bằng project ID");
		System.out.println( "4. Thoát");
		System.out.println("+--------------------------------------------------------------------------+");
	}
}
