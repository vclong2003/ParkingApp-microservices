package com.vti.frontend;

import java.sql.SQLException;
import java.util.List;

import com.vti.backend.presentationlayer.UsersController;
import com.vti.backend.utils.ScannerUtil;
import com.vti.entity.Employee;
import com.vti.entity.Manager;



public class UserFunction {
	public static void getAllEmployeeByProjectId() {
		UsersController con;
		try {
			con = new UsersController();
			int projectId;
			while (true) {
				projectId = ScannerUtil.inputId("Input project id: ");
				if (!con.isProjectIdExists(projectId)) {
					System.out.println("Please enter project id again because it not exists: ");
				} else {
					break;
				}
			}
			
			List<Employee> emps = con.getEmployeesByProjectId(projectId);
			
			if (emps.size() == 0) {
				System.out.println("There is no Employee");
				return;
			}
			
			String leftAlignFormat = "|  %-6s  |  %-25s  |  %-25s  |  %-9s  |  %-10s  |  %-7s  |%n";
			System.out.format("+----------------------------------------------------------------------------------------------------------------+%n");
			System.out.format("|  ID      |  Full name                  |  Email                      |  Pro Skill  |  Project ID  |  Role      |%n");
			System.out.format("+----------------------------------------------------------------------------------------------------------------+%n");
			for (Employee e : emps) {
				System.out.printf(leftAlignFormat, e.getId(), e.getFullName(), e.getEmail(), e.getProSkill(), e.getProjectId(), e.getRole());
			}
			System.out.format("+----------------------------------------------------------------------------------------------------------------+%n");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	public static void getAllManagerByProjectId() {
		UsersController con;
		try {
			con = new UsersController();
			int projectId;
			while (true) {
				projectId = ScannerUtil.inputId("Input project id: ");
				if (!con.isProjectIdExists(projectId)) {
					System.out.println("Please enter project id again because it not exists: ");
				} else {
					break;
				}
			}
			
			List<Manager> mngs = con.getManagerByProjectId(projectId);
			
			if (mngs.size() == 0) {
				System.out.println("There is no Manager");
				return;
			}
			
			String leftAlignFormat = "|  %-6s  |  %-25s  |  %-25s  |  %-11s  |  %-10s  |  %-8s  |%n";
			System.out.format("+------------------------------------------------------------------------------------------------------------------+%n");
			System.out.format("|  ID      |  Full name                  |  Email                      |  Exp In Year  |  Project ID  |  Role      |%n");
			System.out.format("+------------------------------------------------------------------------------------------------------------------+%n");
			for (Manager m : mngs) {
				System.out.printf(leftAlignFormat, m.getId(), m.getFullName(), m.getEmail(), m.getExpInYear(), m.getProjectId(), m.getRole());
			}
			System.out.format("+------------------------------------------------------------------------------------------------------------------+%n");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
