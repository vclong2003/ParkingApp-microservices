DROP DATABASE IF EXISTS final_exam;
CREATE DATABASE final_exam;
USE final_exam;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
	id           INT PRIMARY KEY AUTO_INCREMENT,
    full_name    VARCHAR(255)                          NOT NULL,
    email        VARCHAR(255) UNIQUE KEY               NOT NULL,
    password     VARCHAR(255)                          NOT NULL,
    role         ENUM('EMPLOYEE', 'MANAGER')                  ,
    pro_skill    ENUM('PHP', 'TEST', 'JAVA', 'PYTHON')		  ,
    project_id   INT										  ,
    exp_in_year INT DEFAULT NULL
);

INSERT INTO users (full_name      , email                   ,password     ,role       ,pro_skill         ,project_id    ,exp_in_year)
VALUES			  ('HUynh VU toan', 'toanvu@gmail.com'		,'123456'	  ,'EMPLOYEE' ,'JAVA'            ,1				,NULL       ),
				  ('BA Thong'     , 'bathong@gmail.com'     ,'123123'     ,'MANAGER'  ,NULL              ,1				,10         ),
                  ('Chien Thang'  , 'thangch@gmail.com'     ,'111222'     ,'EMPLOYEE' ,'PYTHON'          ,2				,NULL       ),
                  ('Huong Mai'    , 'maihuong@gmail.com'    ,'222222'     ,'EMPLOYEE' ,'PHP'             ,3				,NULL       ), 
                  ('Hoang Anh'    , 'hoanganh@gmail.com'    ,'111111'     ,'MANAGER'  ,NULL              ,2				,6          ), 
                  ('Tran Hao Nam' , 'haonamtran@gmail.com'  ,'444444'     ,'EMPLOYEE' ,'TEST'            ,4				,NULL       ),
                  ('Mai Tai Phien', 'taiphien@gmail.com'    ,'111222'     ,'MANAGER'  ,NULL              ,3				,7          );
                  
                  

    
    
    
    
    
    
    