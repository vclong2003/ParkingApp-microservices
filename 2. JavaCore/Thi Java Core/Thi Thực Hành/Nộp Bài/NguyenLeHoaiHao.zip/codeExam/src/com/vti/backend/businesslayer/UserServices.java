package com.vti.backend.businesslayer;

import java.sql.SQLException;

import com.vti.backend.datalayer.IUserRepository;
import com.vti.backend.datalayer.UserRepository;

public class UserServices implements IUserServices{
	
	private IUserRepository userRepository;

	public UserServices () {
		userRepository = new UserRepository();
	}

	@Override
	public boolean registerManager(String fullName, String email, String password, int expInYear, String projectID)
			throws SQLException {
		// TODO Auto-generated method stub
		return userRepository.registerManager(fullName, email, password, expInYear, projectID);
	}

	@Override
	public boolean registerEmployee(String fullName, String email, String password, String projectID, String proSkill)
			throws SQLException {
		// TODO Auto-generated method stub
		return userRepository.registerEmployee(fullName, email, password, projectID, proSkill);
	}

	@Override
	public boolean showEmployeeByProjectID(String projectID) throws SQLException {
		// TODO Auto-generated method stub
		return userRepository.showEmployeeByProjectID(projectID);
	}

	@Override
	public boolean showAllManagerInProject() throws SQLException {
		// TODO Auto-generated method stub
		return userRepository.showAllManagerInProject();
	}

	@Override
	public boolean login(String email, String password) throws SQLException {
		// TODO Auto-generated method stub
		return userRepository.login(email, password);
	}

}
