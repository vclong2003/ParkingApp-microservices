package com.vti.backend.datalayer;

import java.sql.SQLException;

public interface IUserRepository {
	
	boolean registerManager(String fullName, String email, String password, int expInYear, String projectID) throws SQLException;
	
	boolean registerEmployee(String fullName, String email, String password, String projectID, String proSkill) throws SQLException;
	
	boolean showEmployeeByProjectID(String projectID) throws SQLException;
	
	boolean showAllManagerInProject() throws SQLException;
	
	boolean login(String email, String password) throws SQLException;

}
