package com.vti.backend.datalayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.vti.backend.utils.JDBCUtils;

public class UserRepository implements IUserRepository {

	@Override
	public boolean registerManager(String fullName, String email, String password, int expInYear, String projectID)
			throws SQLException {

		Connection con = JDBCUtils.getConnection();

		String sql = "INSERT INTO `user` (fullname, email, `password`, exp_in_year, project_id, `role`)"
				+ " VALUES (?, ?, ?, ?, ?, 'Manager')";

		PreparedStatement pstmt = con.prepareStatement(sql);

		pstmt.setString(1, fullName);
		pstmt.setString(2, email);
		pstmt.setString(3, password);
		pstmt.setInt(4, expInYear);
		pstmt.setString(5, projectID);

		int rs = pstmt.executeUpdate();

		if (rs > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean registerEmployee(String fullName, String email, String password, String projectID, String proSkill)
			throws SQLException {
		Connection con = JDBCUtils.getConnection();

		String sql = "INSERT INTO `user` (fullname, email, `password`, project_id, pro_skill, `role`)"
				+ " VALUES (?, ?, ?, ?, ?, 'Employee')";

		PreparedStatement pstmt = con.prepareStatement(sql);

		pstmt.setString(1, fullName);
		pstmt.setString(2, email);
		pstmt.setString(3, password);
		pstmt.setString(4, projectID);
		pstmt.setString(5, proSkill);

		int rs = pstmt.executeUpdate();

		if (rs > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean showEmployeeByProjectID(String projectID) throws SQLException {

		Connection con = JDBCUtils.getConnection();

		String sql = "SELECT fullname, email, pro_skill FROM `user` WHERE project_id = ? AND `role` = 'Employee'";

		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, projectID);

		ResultSet rs = pstmt.executeQuery();
		int i = 1;
		while (rs.next()) {
			System.out.println("\nEmployee thu " + i + ": ");
			System.out.println("Full name: " + rs.getString("fullname"));
			System.out.println("Email: " + rs.getString("email"));
			System.out.println("Product Skill: " + rs.getString("pro_skill"));
			i++;
		}

		if (rs.next()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean showAllManagerInProject() throws SQLException {
		Connection con = JDBCUtils.getConnection();

		String sql = "SELECT fullname, email, exp_in_year, project_id FROM `user` WHERE `role` = 'Manager'";

		PreparedStatement pstmt = con.prepareStatement(sql);

		ResultSet rs = pstmt.executeQuery();
		int i = 1;
		System.out.println("\n-- Manager của các project --");
		while (rs.next()) {
			System.out.println("\nManager thứ " + i + ": ");
			System.out.println("Full name: " + rs.getString("fullname"));
			System.out.println("Email: " + rs.getString("email"));
			System.out.println("Exp in year: " + rs.getInt("exp_in_year"));
			System.out.println("Project ID: " + rs.getString("project_id"));
			i++;
		}

		if (rs.next()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean login(String email, String password) throws SQLException {

		Connection con = JDBCUtils.getConnection();

		String sql = "SELECT * FROM `user` WHERE email = ? AND `password` = ?";

		PreparedStatement pstmt = con.prepareStatement(sql);

		pstmt.setString(1, email);
		pstmt.setString(2, password);

		ResultSet rs = pstmt.executeQuery();

		if (rs.next()) {
			String fullName = rs.getString(2);
			String email1 = rs.getString(3);
			int expInYear = rs.getInt(5);
			String projectID = rs.getString(6);
			String proSkill = rs.getString(7);
			String role = rs.getString(8);
			System.out.println("\nThông tin của tài khoản: \n");
			System.out.println("Fullname: " + fullName);
			System.out.println("Email: " + email1);
			System.out.println("Exp In Year: " + expInYear);
			System.out.println("Project ID: " + projectID);
			System.out.println("ProSkill: " + proSkill);
			System.out.println("Role" + role);
			return true;
		} else {
			return false;
		}
	}

}
