package com.vti.backend.presentationlayer;

import java.sql.SQLException;

import com.vti.backend.businesslayer.IUserServices;
import com.vti.backend.businesslayer.UserServices;

public class UserController {

	private IUserServices userServices;

	public UserController() {
		userServices = new UserServices();
	}

	public boolean registerManager(String fullName, String email, String password, int expInYear, String projectID)
			throws SQLException {
		return userServices.registerManager(fullName, email, password, expInYear, projectID);
	}

	public boolean registerEmployee(String fullName, String email, String password, String projectID, String proSkill)
			throws SQLException {
		return userServices.registerEmployee(fullName, email, password, projectID, proSkill);
	}
	
	public boolean showEmployeeByProjectID(String projectID) throws SQLException {
		return userServices.showEmployeeByProjectID(projectID);
	}

	public boolean showAllManagerInProject() throws SQLException {
		return userServices.showAllManagerInProject();
	}
	
	public boolean login(String email, String password) throws SQLException {
		return userServices.login(email, password);
	}

}
