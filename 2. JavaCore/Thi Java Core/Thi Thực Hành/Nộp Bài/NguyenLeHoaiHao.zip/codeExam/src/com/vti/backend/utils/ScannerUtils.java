package com.vti.backend.utils;

import java.util.Scanner;

public class ScannerUtils {

	private static Scanner scanner = new Scanner(System.in);
	

	public static int inputId(String msg) {
		while (true) {
			System.out.println(msg);
			int id = inputInt("Please input a id as int, please input again.");
			if (id > 0) {
				return id;
			}
			// else
			System.out.println("Please input a id as int which must be greater than > 0, please input again.");
		}
	}

	public static String inputName(String msg) {
		System.out.println(msg);
		return inputString("Please input a name, please input again.");
	}

	public static int inputInt() {
		return inputInt("Bạn phải nhập số. Xin cảm ơn.");
	}

	public static int inputInt(String errorMessage) {
		while (true) {
			try {
				return Integer.parseInt(scanner.nextLine().trim());
			} catch (Exception e) {
				e.printStackTrace();
				System.err.println(errorMessage);
			}
		}
	}

	public static float inputFloat(String errorMessage) {
		while (true) {
			try {
				return Float.parseFloat(scanner.nextLine().trim());
			} catch (Exception e) {
				System.err.println(errorMessage);
			}
		}
	}

	public static double inputDouble(String errorMessage) {
		while (true) {
			try {
				return Double.parseDouble(scanner.nextLine().trim());
			} catch (Exception e) {
				System.err.println(errorMessage);
			}
		}
	}

	public static String inputString(String errorMessage) {
		while (true) {
			String input = scanner.nextLine().trim();
			if (!input.isEmpty()) {
				return input;
			} else {
				System.err.println(errorMessage);
			}
		}
	}

	public static int inputAge() {
		while (true) {
			int age = inputInt("Wrong inputing! Please input an age as int, input again.");

			if (age <= 0) {
				System.err.println("Wrong inputing! The age must be greater than 0, please input again.");

			} else {
				return age;
			}
		}
	}

	public static int inputAgeGreaterThan18() {
		while (true) {
			int age = inputAge();

			if (age >= 18) {
				return age;

			} else {
				System.out.println("Wrong inputing! The age must be greater than 18, please input again.");
			}
		}
	}
	
	public static String inputPassword() {
		while (true) {
			String password = ScannerUtils.inputString("");
			if (password.length() < 6 || password.length() > 12) {
				System.out.println("Password từ 6 tới 12 ký tự");
				System.out.print("Nhập lại: ");
				continue;
			}
//			boolean hasAtLeast1Character = false;
//			for (int i = 0; i < password.length(); i++) {
//				if (Character.isUpperCase(password.charAt(i)) == true) {
//					hasAtLeast1Character = true;
//					break;
//				}
//			}

//			if (hasAtLeast1Character == true) {
//				return password;
//			} else {
//				System.out.print("Mời bạn nhập lại password: ");
//			}
			return password;
		}
	}
	
	public static String inputEmail() {
		while (true) {
			String email = scanner.nextLine();// equals(); so sanh gtri,   == so sánh địa chỉ ,  biểu thức chính quy, matches(): so sánh  theo quy tắc
			if (email == null || !email.matches("^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")) {// a@b
				System.out.print("Nhập lại: ");
			} else {
				return email;
			}
		}
	}
	
	public static void closeProgram() {
		System.out.println("Exit");
		System.exit(0);
	}

}
