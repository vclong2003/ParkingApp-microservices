package com.vti.entity;

public class Employee {

	private String projectID;
	private String proSkill;

	public String getProjectID() {
		return projectID;
	}

	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}

	public String getProSkill() {
		return proSkill;
	}

	public void setProSkill(String proSkill) {
		this.proSkill = proSkill;
	}

	public Employee(String projectID, String proSkill) {
		super();
		this.projectID = projectID;
		this.proSkill = proSkill;
	}

	public Employee() {
	}

}
