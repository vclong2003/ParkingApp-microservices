package com.vti.entity;

public class Manager extends User {

	private int expInYear;
	private String projectID;

	public int getExpInYear() {
		return expInYear;
	}

	public void setExpInYear(int expInYear) {
		this.expInYear = expInYear;
	}

	public String getProjectID() {
		return projectID;
	}

	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}

	public Manager(int id, String fullName, String email, String password, Role role, int expInYear, String projectID) {
		super(id, fullName, email, password, role);
		this.expInYear = expInYear;
		this.projectID = projectID;
	}

	public Manager() {
	}

}
