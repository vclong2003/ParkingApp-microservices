package com.vti.frontend;

import java.sql.SQLException;
import java.util.Scanner;

import com.vti.backend.presentationlayer.UserController;
import com.vti.backend.utils.ScannerUtils;

public class Function {
	
	public void showEmployeeByProjectID() {
		UserController usController = new UserController();
		Scanner sc = new Scanner(System.in);
		
		try {
			System.out.print("Nhập ProjectID: ");
			String proID = sc.nextLine();
			
			System.out.println("\nEmployee của ProjectID: " + proID);
			
			boolean check = usController.showEmployeeByProjectID(proID);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void showAllManagerInProject() {
		UserController usController = new UserController();
		try {
			boolean check = usController.showAllManagerInProject();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void login() {
		UserController usController = new UserController();
		Scanner sc = new Scanner(System.in);
		try {
			System.out.print("Nhập email: ");
			String email = ScannerUtils.inputEmail();
			
			System.out.print("Nhập password: ");
			String password = ScannerUtils.inputPassword();
			
			boolean check = usController.login(email, password);
			
			if(check) {
				System.out.println("\nĐăng nhập thành công.");
			} else {
				System.out.println("\nTài khoản không tồn tại !");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
		

}
