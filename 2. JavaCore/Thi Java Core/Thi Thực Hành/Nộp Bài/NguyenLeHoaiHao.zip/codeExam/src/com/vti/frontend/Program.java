package com.vti.frontend;

import java.util.Scanner;

import com.vti.backend.utils.JDBCUtils;

public class Program {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Function function = new Function();
		
		System.out.println(" 1. Xem các Emplyee  \n 2. Xem các Manager  \n 3. Login");
		System.out.print("Mời bạn đăng nhập: ");
		int n = scanner.nextInt();
		scanner.nextLine();
		
		switch (n) {
		case 1:
			function.showEmployeeByProjectID();
			break;

		case 2:
			function.showAllManagerInProject();
			break;
			
		case 3:
			function.login();
			break;
		}
		
	}

}
