package com.vti.backend.businesslayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.entity.employee;
import com.vti.entity.manager;

public interface IUserServices {
	public boolean registerManager(manager mn) throws SQLException;
	public boolean registerEmployee(employee ee) throws SQLException;
	public boolean login(String username, String password) throws SQLException;
	public void display(int ProjectId) throws SQLException;
	public List<manager> getAllMn() throws SQLException;
}
