package com.vti.backend.businesslayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.backend.datalayer.IUserRepository;
import com.vti.backend.datalayer.UserRepository;
import com.vti.entity.employee;
import com.vti.entity.manager;

public class UserServices implements IUserServices {
	private IUserRepository userrepo;
	public UserServices() {
		userrepo = new UserRepository();
	}
	
	@Override
	public boolean registerManager(manager mn) throws SQLException {
		return userrepo.insertManager(mn);
	}
	
	@Override
	public boolean registerEmployee(employee ee) throws SQLException {
		return userrepo.insertEmployee(ee);
	}
	
	@Override
	public boolean login(String username, String password) throws SQLException {
		return userrepo.checkExist(username, password);
	}
	@Override
	public void display(int ProjectId) throws SQLException{
		userrepo.display(ProjectId);
	}
	@Override
	public List<manager> getAllMn() throws SQLException{
		return userrepo.getAllMn();
	}
}
