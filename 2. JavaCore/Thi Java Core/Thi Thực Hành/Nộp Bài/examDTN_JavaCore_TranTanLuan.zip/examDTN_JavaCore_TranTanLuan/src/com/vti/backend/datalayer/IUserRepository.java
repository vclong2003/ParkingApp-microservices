package com.vti.backend.datalayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.entity.employee;
import com.vti.entity.manager;

public interface IUserRepository {
	public boolean insertManager(manager mn) throws SQLException;
	public boolean insertEmployee(employee ee) throws SQLException;
	public boolean checkExist(String username, String password) throws SQLException;
	public void display(int ProjectId) throws SQLException;
	public List<manager> getAllMn() throws SQLException;
}
