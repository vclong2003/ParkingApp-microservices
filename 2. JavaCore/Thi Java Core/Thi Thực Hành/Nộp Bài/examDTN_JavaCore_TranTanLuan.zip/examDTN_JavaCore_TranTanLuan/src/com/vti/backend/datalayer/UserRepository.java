package com.vti.backend.datalayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vti.backend.utils.JDBCUtils;
import com.vti.entity.employee;
import com.vti.entity.manager;

public class UserRepository implements IUserRepository {
	@Override
	public boolean insertManager(manager mn) throws SQLException {
		Connection con = JDBCUtils.getConnection();
		String sql = "insert into UsersExam (Id,FullName,Email,Pwd,ExpInYear,ProjectId,ProSkill,Roles) values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, mn.getId());
		pstmt.setString(2, mn.getFullName());
		pstmt.setString(3, mn.getEmail());
		pstmt.setString(4, mn.getPwd());
		pstmt.setInt(5, mn.getExpInYear());
		pstmt.setInt(6, mn.getProjectId());
		pstmt.setString(7, null);
		pstmt.setString(8, "manager");
		int rs = pstmt.executeUpdate();
		JDBCUtils.closeConnection(con, null, pstmt, null);
		if (rs >= 0) {
			return true;
		} else {
			return false;
		}
	}
	@Override
	public boolean insertEmployee(employee ee) throws SQLException {
		Connection con = JDBCUtils.getConnection();
		String sql = "insert into UsersExam (Id,FullName,Email,Pwd,ExpInYear,ProjectId,ProSkill,Roles) values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, ee.getId());
		pstmt.setString(2, ee.getFullName());
		pstmt.setString(3, ee.getEmail());
		pstmt.setString(4, ee.getPwd());
		pstmt.setInt(5, 0);
		pstmt.setInt(6, ee.getProjectId());
		pstmt.setString(7, ee.getProSkill());
		pstmt.setString(8, "employee");
		int rs = pstmt.executeUpdate();
		JDBCUtils.closeConnection(con, null, pstmt, null);
		if (rs >= 0) {
			return true;
		} else {
			return false;
		}
	}
	@Override
	public boolean checkExist(String username, String password) throws SQLException {
		Connection connection = JDBCUtils.getConnection();
		String sql = "select Email, Pwd, Roles from UsersExam";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		int i = 1;
		String default_role = "manager";
		while (rs.next()) {
			if (username.equals(rs.getString("Email")) && password.equals(rs.getString("Pwd")) && default_role.equals(rs.getString("Roles"))) {
				return true;
			}
			i++;
		}
		JDBCUtils.closeConnection(connection, rs, pstmt, null);
		return false;
	}
	@Override
	public void display(int ProjectId) throws SQLException {
		Connection connection = JDBCUtils.getConnection();
		String sql = "select * from UsersExam";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		int i = 1;
		System.out.printf("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n", "Id", "FullName", "Email", "Pwd", "ExpInYear", "ProjectId", "ProSkill", "Roles");
		while (rs.next()) {
			if (ProjectId == rs.getInt("ProjectId")) {
		        System.out.printf("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n", rs.getInt("Id"), rs.getString("FullName"), rs.getString("Email"), rs.getString("Pwd"), rs.getInt("ExpInYear"), rs.getInt("ProjectId"), rs.getString("ProSkill"), rs.getString("Roles"));
			}
		}
		JDBCUtils.closeConnection(connection, rs, pstmt, null);
	}
	@Override
	public List<manager> getAllMn() throws SQLException {
		List<manager> ls = new ArrayList<manager>();
		Connection connection = JDBCUtils.getConnection();
		String sql = "select * from UsersExam";
		PreparedStatement pstmt = connection.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		int i = 1;
		while (rs.next()) {
			if ((rs.getString("Roles")).equals("manager")) {
				ls.add(new manager(rs.getInt("Id"), rs.getString("FullName"), rs.getString("Email"), rs.getString("Pwd"), rs.getInt("ExpInYear"), rs.getInt("ProjectId")));
			}
		}
		JDBCUtils.closeConnection(connection, rs, pstmt, null);
		return ls;
	}
}
