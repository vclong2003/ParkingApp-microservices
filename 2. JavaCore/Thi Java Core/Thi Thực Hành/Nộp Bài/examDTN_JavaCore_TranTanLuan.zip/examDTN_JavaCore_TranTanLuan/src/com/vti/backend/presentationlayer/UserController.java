package com.vti.backend.presentationlayer;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.vti.backend.businesslayer.IUserServices;
import com.vti.backend.businesslayer.UserServices;
import com.vti.entity.employee;
import com.vti.entity.manager;

public class UserController {
	public IUserServices userser;
	public UserController() {
		userser = new UserServices();
	}
	public boolean registerManager(manager mn) throws SQLException {
		return userser.registerManager(mn);
	}
	public boolean registerEmployee(employee ee) throws SQLException {
		return userser.registerEmployee(ee);
	}
	public boolean login(String username, String password) throws SQLException {
		String regex = "^[a-zA-Z0-9]+@[vti.com.vn]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(username);
		if (!(matcher.find())) {
			return false;
		}
		if (!(password.length() >= 6 && password.length() <= 12)) {
			return false;
		}
		return userser.login(username, password);
	}
	public void display(int ProjectId) throws SQLException{
		userser.display(ProjectId);
	}
	public List<manager> getAllMn() throws SQLException{
		return userser.getAllMn();
	}
}
