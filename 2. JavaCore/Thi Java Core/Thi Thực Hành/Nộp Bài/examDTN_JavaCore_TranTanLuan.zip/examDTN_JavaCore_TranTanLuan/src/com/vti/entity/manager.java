package com.vti.entity;

public class manager {
	private int Id;
	private String FullName;
	private String Email;
	private String Pwd;
	private int ProjectId;
	private int ExpInYear;
	
	public manager(int Id, String FullName, String Email, String Pwd, int ProjectId, int ExpInYear) {
		this.Id = Id;
		this.FullName = FullName;
		this.Email = Email;
		this.Pwd = Pwd;
		this.ProjectId = ProjectId;
		this.ExpInYear = ExpInYear;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		FullName = fullName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPwd() {
		return Pwd;
	}

	public void setPwd(String pwd) {
		Pwd = pwd;
	}

	public int getProjectId() {
		return ProjectId;
	}

	public void setProjectId(int projectId) {
		ProjectId = projectId;
	}

	public int getExpInYear() {
		return ExpInYear;
	}

	public void setExpInYear(int expInYear) {
		ExpInYear = expInYear;
	}
	
}
