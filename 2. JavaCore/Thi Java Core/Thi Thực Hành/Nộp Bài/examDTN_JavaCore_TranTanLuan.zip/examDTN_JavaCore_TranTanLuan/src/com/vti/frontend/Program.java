package com.vti.frontend;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.vti.backend.presentationlayer.UserController;
import com.vti.backend.utils.JDBCUtils;
import com.vti.entity.employee;
import com.vti.entity.manager;


public class Program {
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		UserController usercontrl = new UserController();
		boolean isLogin = false;
		while (true) {
			loginMenu();
			System.out.println("Enter the following numbers to choose the functions: 1, 2, 3, 4, 5, 6");
			int choose = scanner.nextInt();
			if (choose == 1) {
				System.out.println("Enter email: ");
				String email = scanner.next();
				System.out.println("Enter password: ");
				String password = scanner.next();
				try {
					if (usercontrl.login(email, password)) {
						System.out.println("Successful login!");
						isLogin = true;
					}
					else {
						System.out.println("Fail login!");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("Error login!");
					e.printStackTrace();
				}
			}
			else if (choose == 2) {
				System.out.println("Enter Id: ");
				int Id = scanner.nextInt();
				System.out.println("Enter FullName: ");
				String FullName = scanner.next();
				System.out.println("Enter Email: ");
				String Email = scanner.next();
				System.out.println("Enter Pwd: ");
				String Pwd = scanner.next();
				System.out.println("Enter ExpInYear: ");
				int ExpInYear = scanner.nextInt();
				System.out.println("Enter ProjectId: ");
				int ProjectId = scanner.nextInt();
				manager mn = new manager(Id, FullName, Email, Pwd, ProjectId, ExpInYear);
				try {
					if (usercontrl.registerManager(mn)) {
						System.out.println("Successfull register manager!");
					}
					else {
						System.out.println("Fail register manager!");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("Error register manager!");
					e.printStackTrace();
				}
			}
			if (choose == 3) {
				System.out.println("Enter Id: ");
				int Id = scanner.nextInt();
				System.out.println("Enter FullName: ");
				String FullName = scanner.next();
				System.out.println("Enter Email: ");
				String Email = scanner.next();
				System.out.println("Enter Pwd: ");
				String Pwd = scanner.next();
				System.out.println("Enter ProSkill: ");
				String ProSkill = scanner.next();
				System.out.println("Enter ProjectId: ");
				int ProjectId = scanner.nextInt();
				employee ee = new employee(Id, FullName, Email, Pwd, ProjectId, ProSkill);
				try {
					if (usercontrl.registerEmployee(ee)) {
						System.out.println("Successfull register Employee!");
					}
					else {
						System.out.println("Fail register Employee!");
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("Error register Employee!");
					e.printStackTrace();
				}
			}
			else if (choose == 4){
				try {
					usercontrl.display(0);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else if (choose == 5){
				try {
					List<manager> ls = new ArrayList<manager>();
					ls = usercontrl.getAllMn();
					System.out.printf("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n", "Id", "FullName", "Email", "Pwd", "ExpInYear", "ProjectId", "ProSkill", "Roles");
					int i = 0;
					for (manager mn: ls) {
				        System.out.printf("%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n", mn.getId(),mn.getFullName(),mn.getEmail(),mn.getPwd(), mn.getExpInYear(), mn.getProjectId(), null, "manager");
				        i+=1;
					}
					usercontrl.getAllMn();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else if (choose == 6){
				System.out.println("=======Finish!");
				return;
			}
			
			
		}
	}
	public static void loginMenu() {
		System.out.println("==============Login Menu===============");
		System.out.println("1. Login");
		System.out.println("2. Register manager");
		System.out.println("3. Register employee");
		System.out.println("4. Display");
		System.out.println("5. Get all manager");
		System.out.println("6. Exit");
		System.out.println("=======================================");
	}
}
