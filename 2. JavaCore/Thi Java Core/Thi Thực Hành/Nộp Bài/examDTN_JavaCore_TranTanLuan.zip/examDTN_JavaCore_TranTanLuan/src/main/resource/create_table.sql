use salary;

CREATE TABLE UsersExam (
  Id int NOT NULL AUTO_INCREMENT,
  FullName varchar(50) DEFAULT NULL,
  Email varchar(50) DEFAULT NULL,
  Pwd varchar(50) NOT NULL,
  ExpInYear int,
  ProjectId int,
  ProSkill varchar(50),
  Roles varchar(50),
  PRIMARY KEY (Id)
);