package com.vti.backend.businesslayer;

import java.sql.SQLException;

import com.vti.backend.datalayer.UserRepository;
import com.vti.entity.User;

public class UserService {

    private UserRepository userRepository;

    public UserService() {
        userRepository = new UserRepository();
    }

    public boolean registerManager(String fullName, String email, String password, int expInYear, int projectId) throws ClassNotFoundException, SQLException {
        return userRepository.registerManager(fullName, email, password, expInYear, projectId);
    }

    public boolean registerEmployee(String fullName, String email, String password, int projectId, String proSkill) throws ClassNotFoundException, SQLException {
        return userRepository.registerEmployee(fullName, email, password, projectId, proSkill);
    }

    public User login(String email, String password) throws SQLException, ClassNotFoundException {
        return userRepository.login(email, password);
    }

    public boolean isUserExistsByEmail(String email) throws ClassNotFoundException, SQLException {
        return userRepository.isUserExistsByEmail(email);
    }
}
