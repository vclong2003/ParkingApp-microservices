package com.vti.backend.datalayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.vti.backend.utils.JDBCUtils;
import com.vti.entity.Employee;
import com.vti.entity.Manager;
import com.vti.entity.User;
import com.vti.entity.Role;

public class UserRepository {

	private JDBCUtils jdbcUtils;

	public UserRepository() {
		jdbcUtils = new JDBCUtils();
	}
	
	public boolean registerManager(String fullName, String email, String password, int expInYear, int projectId) throws ClassNotFoundException, SQLException {
		try (Connection connection = jdbcUtils.getConnection()) {
			String sql = "INSERT INTO user (full_name, email, password, exp_in_year, project_id, role) VALUES (?, ?, ?, ?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, fullName);
				statement.setString(2, email);
				statement.setString(3, password);
				statement.setInt(4, expInYear);
				statement.setInt(5, projectId);
				statement.setString(6, "Manager");
				
				int affectedRows = statement.executeUpdate();
				return affectedRows > 0;
			}
		}
	}

	public boolean registerEmployee(String fullName, String email, String password, int projectId, String proSkill) throws ClassNotFoundException, SQLException {
		try (Connection connection = jdbcUtils.getConnection()) {
			String sql = "INSERT INTO user (full_name, email, password, project_id, pro_skill, role) VALUES (?, ?, ?, ?, ?, ?)";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, fullName);
				statement.setString(2, email);
				statement.setString(3, password);
				statement.setInt(4, projectId);
				statement.setString(5, proSkill);
				statement.setString(6, "Employee");
				
				int affectedRows = statement.executeUpdate();
				return affectedRows > 0;
			}
		}
	}

	public User login(String email, String password) throws SQLException, ClassNotFoundException {
		try (Connection connection = jdbcUtils.getConnection()) {
			String sql = "SELECT * FROM user WHERE email = ? AND password = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, email);
				statement.setString(2, password);
				
				try (ResultSet resultSet = statement.executeQuery()) {
					if (resultSet.next()) {
						int id = resultSet.getInt("id");
						String fullName = resultSet.getString("full_name");
						String role = resultSet.getString("role");
						Role rol = role.equals("Manager") ? Role.Manager : Role.Employee;
						
						if (role.equals("Manager")) {
							int expInYear = resultSet.getInt("exp_in_year");
							int projectId = resultSet.getInt("project_id");
							return new Manager(id, fullName, email, password, expInYear, projectId,rol);
						} else {
							int projectId = resultSet.getInt("project_id");
							String proSkill = resultSet.getString("pro_skill");
							return new Employee(id, fullName, email, password, projectId, proSkill,rol);
						}
					}
				}
			}
		}
		return null;
	}

	public boolean isUserExistsByEmail(String email) throws ClassNotFoundException, SQLException {
		try (Connection connection = jdbcUtils.getConnection()) {
			String sql = "SELECT 1 FROM user WHERE email = ?";
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setString(1, email);
				
				try (ResultSet resultSet = statement.executeQuery()) {
					return resultSet.next();
				}
			}
		}
	}
}

