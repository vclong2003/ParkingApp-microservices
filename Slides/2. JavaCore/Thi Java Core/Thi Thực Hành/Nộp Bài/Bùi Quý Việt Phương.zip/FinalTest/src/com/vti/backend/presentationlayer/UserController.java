package com.vti.backend.presentationlayer;

import java.sql.SQLException;

import com.vti.backend.businesslayer.UserService;
import com.vti.entity.User;

public class UserController {

    private UserService userService;

    public UserController() {
        userService = new UserService();
    }

    public boolean registerManager(String fullName, String email, String password, int expInYear, int projectId) {
        try {
            return userService.registerManager(fullName, email, password, expInYear, projectId);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error during registration: " + e.getMessage());
            return false;
        }
    }

    public boolean registerEmployee(String fullName, String email, String password, int projectId, String proSkill) {
        try {
            return userService.registerEmployee(fullName, email, password, projectId, proSkill);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error during registration: " + e.getMessage());
            return false;
        }
    }

    public User login(String email, String password) {
        try {
            return userService.login(email, password);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error during login: " + e.getMessage());
            return null;
        }
    }

    public boolean isUserExistsByEmail(String email) {
        try {
            return userService.isUserExistsByEmail(email);
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error checking email existence: " + e.getMessage());
            return false;
        }
    }
}

