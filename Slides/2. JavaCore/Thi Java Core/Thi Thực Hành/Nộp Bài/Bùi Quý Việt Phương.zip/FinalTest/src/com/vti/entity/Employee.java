package com.vti.entity;

import com.vti.entity.Role;

public class Employee extends User {
    private int projectId;
    private String proSkill;

    public Employee(int id, String fullName, String email, String password, int projectId, String proSkill,Role role) {
        super(id, fullName, email, password, role);
        this.projectId = projectId;
        this.proSkill = proSkill;
    }

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProSkill() {
		return proSkill;
	}

	public void setProSkill(String proSkill) {
		this.proSkill = proSkill;
	}

    // Getters and setters
    
}
