package com.vti.frontend;

import java.sql.SQLException;
import java.util.Scanner;

import com.vti.backend.presentationlayer.UserController;
import com.vti.entity.User;

public class Function {

    private UserController userController;
    private Scanner scanner;

    public Function() {
        userController = new UserController();
        scanner = new Scanner(System.in);
    }

    public void login() throws SQLException {
        try {
            while (true) {
                System.out.print("Nhập email của bạn: ");
                String email = scanner.nextLine();

                if (!email.isEmpty()) {
                    System.out.print("Nhập mật khẩu: ");
                    String password = scanner.nextLine();

                    if (!password.isEmpty()) {
                        User user = userController.login(email, password);

                        if (user != null) {
                            System.out.printf("Xin chào %s (%s) \n \n \n",
                                    user.getFullName(), user.getRole());
                            return;
                        } else {
                            System.err.println("Email hoặc mật khẩu không đúng! Vui lòng thử lại!");
                        }
                    } else {
                        System.err.println("Mật khẩu không được để trống! Vui lòng thử lại!");
                    }
                } else {
                    System.err.println("Email không được để trống! Vui lòng thử lại!");
                }
            }
        } finally {
            // Không cần đóng Scanner ở đây
        }
    }

    public void addManager() {
        try {
            System.out.print("Nhập họ và tên của quản lý: ");
            String fullName = scanner.nextLine();

            System.out.print("Nhập email của quản lý: ");
            String email = scanner.nextLine();

            System.out.print("Nhập mật khẩu: ");
            String password = scanner.nextLine();

            System.out.print("Nhập số năm kinh nghiệm: ");
            int expInYear = scanner.nextInt();

            System.out.print("Nhập mã dự án: ");
            int projectId = scanner.nextInt();

            boolean check = userController.registerManager(fullName, email, password, expInYear, projectId);
            if (check)
                System.out.println("Thêm mới quản lý thành công");
            else
                System.out.println("Thêm mới quản lý không thành công");
        } finally {
            // Không cần đóng Scanner ở đây
        }
    }

    public void addEmployee() {
        try {
            System.out.print("Nhập họ và tên của nhân viên: ");
            String fullName = scanner.nextLine();

            System.out.print("Nhập email của nhân viên: ");
            String email = scanner.nextLine();

            System.out.print("Nhập mật khẩu: ");
            String password = scanner.nextLine();

            System.out.print("Nhập mã dự án: ");
            int projectId = scanner.nextInt();
            scanner.nextLine(); // Đọc bỏ ký tự '\n'

            System.out.print("Nhập kỹ năng chuyên môn: ");
            String proSkill = scanner.nextLine();

            boolean check = userController.registerEmployee(fullName, email, password, projectId, proSkill);
            if (check)
                System.out.println("Thêm mới nhân viên thành công");
            else
                System.out.println("Thêm mới nhân viên không thành công");
        } finally {
            // Không cần đóng Scanner ở đây
        }
    }
}
