package com.vti.frontend;
import java.sql.SQLException;
import java.util.Scanner;

import com.vti.frontend.Function;


public class Program {
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		register();
	}

	public static void register() throws ClassNotFoundException, SQLException {
	    Function function = new Function();
	    System.out.println("Mời bạn đăng kí.\n 1. Đăng kí Manager  \n 2. Đăng kí Employee");
	    int n = scanner.nextInt();
	    scanner.nextLine(); // Đọc dòng mới

	    switch (n) {
	        case 1:
	            function.addManager();
	            break;

	        case 2:
	            function.addEmployee();
	            break;
	    }
	    System.out.println("Mời bạn đăng nhập");
	    function.login();
	}



}