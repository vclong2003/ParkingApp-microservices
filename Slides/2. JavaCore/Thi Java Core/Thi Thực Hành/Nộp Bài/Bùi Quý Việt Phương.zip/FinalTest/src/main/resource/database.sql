
CREATE DATABASE IF NOT EXISTS EmployeeManagement;


USE EmployeeManagement;


CREATE TABLE IF NOT EXISTS User (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    exp_in_year INT,
    pro_skill VARCHAR(255),
    project_id INT,
    role ENUM('manager', 'employee') NOT NULL
);

CREATE UNIQUE INDEX idx_email ON User(email);