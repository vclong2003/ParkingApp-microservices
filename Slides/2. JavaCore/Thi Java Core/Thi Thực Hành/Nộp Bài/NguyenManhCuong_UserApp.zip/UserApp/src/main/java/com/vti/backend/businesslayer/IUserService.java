package com.vti.backend.businesslayer;

import java.sql.SQLException;
import com.vti.entity.User;

public interface IUserService {
	boolean registerManager(String fullName, String email, String password, int expInYear, int projectId) throws ClassNotFoundException, SQLException;
	boolean registerEmp(String fullName, String email, String password, String proSkill, int projectId) throws SQLException, ClassNotFoundException;
	boolean isExistsEmail(String email) throws ClassNotFoundException, SQLException;
	User login(String email, String password) throws SQLException, ClassNotFoundException;
}
