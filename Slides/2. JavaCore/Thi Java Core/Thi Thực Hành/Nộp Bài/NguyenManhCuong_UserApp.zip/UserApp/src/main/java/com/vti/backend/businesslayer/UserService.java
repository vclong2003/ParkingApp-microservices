package com.vti.backend.businesslayer;

import java.sql.SQLException;

import com.vti.backend.datalayer.UserRepository;
import com.vti.entity.User;


public class UserService implements IUserService {

	private UserRepository userRepository;
	
	public UserService() {
		userRepository = new UserRepository();
	}

	public boolean registerManager(String fullName, String email, String password, int expInYear, int projectId)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return userRepository.insertManager(fullName, email, password, expInYear, projectId);
	}

	public boolean registerEmp(String fullName, String email, String password, String proSkill, int projectId)
			throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return userRepository.insertEmployee(fullName, email, password, proSkill, projectId);
	}

	public boolean isExistsEmail(String email) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return userRepository.isExistsEmail(email);
	}

	public User login(String email, String password) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return userRepository.login(email, password);
	}
}
