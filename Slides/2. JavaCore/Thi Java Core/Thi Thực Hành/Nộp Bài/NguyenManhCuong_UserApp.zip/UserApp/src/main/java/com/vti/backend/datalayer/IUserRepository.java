package com.vti.backend.datalayer;

import java.sql.SQLException;
import com.vti.entity.User;

public interface IUserRepository {
	boolean insertManager(String fullName, String email, String password, int expInYear, int projectId) throws SQLException;
	boolean insertEmployee(String fullName, String email, String password, String proSkill, int projectId) throws SQLException;
	User login(String email, String password) throws SQLException, ClassNotFoundException;
	boolean isExistsEmail(String email) throws ClassNotFoundException, SQLException;
}
