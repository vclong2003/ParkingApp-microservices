package com.vti.backend.datalayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.vti.backend.utils.JDBCUtils;
import com.vti.entity.Manager;
import com.vti.entity.Role;
import com.vti.entity.User;

public class UserRepository implements IUserRepository {
	
	public User login(String email, String password) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Connection connection = JDBCUtils.getConnection();
		String sql = "select * from user where Email = ? and `Password` = ?";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, email);
		statement.setString(2, password);
		ResultSet resultSet = statement.executeQuery();
		if (resultSet.next()) {
			int id = resultSet.getInt(1);
			String fullName = resultSet.getString(2);
			String role = resultSet.getString(5);
			Role rol = role.equals("Manager") ? Role.Manager : Role.Employee;

			if (role.equals("Manager")) {
				int expInYear = resultSet.getInt(6);
				int projectId = resultSet.getInt(7);

				User e = new Manager(id, fullName, email, password, rol, expInYear, projectId);
				return e;
			} 
		}
		return null;
	}

	public boolean isExistsEmail(String email) throws ClassNotFoundException, SQLException {
		Connection connection = JDBCUtils.getConnection();
		String sql = "SELECT 1 FROM user WHERE Email = ? "; // select 1 vì ko cần trả về kết quả cụ thể 
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, email);
		ResultSet resultSet = statement.executeQuery();
		if (resultSet.next()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean insertManager(String fullName, String email, String password, int expInYear, int projectId)
			throws SQLException {
		Connection connection = JDBCUtils.getConnection();
		String sql = "INSERT INTO user (FullName, Email, Password, ExpInYear, ProjectId, Role)" +
				" VALUES (?, ?, ?, ?, ?, 'Manager');";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, fullName);
		statement.setString(2, email);
		statement.setString(3,  password);
		statement.setInt(4, expInYear);
		statement.setInt(5, projectId);
		int rsInt = statement.executeUpdate();
		JDBCUtils.closeConnection(connection, null, statement, null);
		return rsInt >= 0;
	}

	public boolean insertEmployee(String fullName, String email, String password, String proSkill, int projectId)
			throws SQLException {
		Connection connection = JDBCUtils.getConnection();
		String sql = "INSERT INTO user (FullName, Email, Password, ProSkill, ProjectId, Role)" +
				" VALUES (?, ?, ?, ?, ?, 'Employee');";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, fullName);
		statement.setString(2, email);
		statement.setString(3,  password);
		statement.setString(4, proSkill);
		statement.setInt(5, projectId);
		int rsInt = statement.executeUpdate();
		JDBCUtils.closeConnection(connection, null, statement, null);
		return rsInt >= 0;
	}
}
