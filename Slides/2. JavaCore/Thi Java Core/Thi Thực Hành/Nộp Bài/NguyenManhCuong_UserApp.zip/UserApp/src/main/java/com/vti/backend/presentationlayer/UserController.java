package com.vti.backend.presentationlayer;

import java.sql.SQLException;

import com.vti.backend.businesslayer.UserService;
import com.vti.entity.User;

public class UserController {

	private UserService userService;

	public UserController() {
		userService = new UserService();
	}

	public boolean registerManager(String fullName, String email, String password, int expInYear, int projectId) throws ClassNotFoundException, SQLException {
		return userService.registerManager(fullName, email, password, expInYear, projectId);
	}

	public boolean registerEmp(String fullName, String email, String password, String proSkill, int projectId) throws ClassNotFoundException, SQLException {
		return userService.registerEmp(fullName, email, password, proSkill, projectId);
	}

	public boolean isExistsEmail(String email) throws ClassNotFoundException, SQLException {
		return userService.isExistsEmail(email);
	}
	
	public User login(String email, String password) throws SQLException, ClassNotFoundException {
		return userService.login(email, password);
	}
}
