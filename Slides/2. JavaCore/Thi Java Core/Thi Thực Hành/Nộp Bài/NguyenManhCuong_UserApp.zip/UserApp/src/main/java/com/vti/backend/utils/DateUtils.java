package com.vti.backend.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
	public String convertDateYMDToDMY(Date date) {
		return new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(date);
	}
}
