package com.vti.entity;

public class Manager extends User {
	private int expInYear, projectId;

	public Manager(int id, String fullName, String email, String password, Role role, int expInYear, int projectId) {
		super(projectId, fullName, email, password, role);
		this.expInYear = expInYear;
		this.projectId = projectId;		
	}

	public int getProjectId() {
		return projectId;
	}
	
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	
	public int getExpInYear() {
		return expInYear;
	}

	public void setExpInYear(int expInYear) {
		this.expInYear = expInYear;
	}
}


