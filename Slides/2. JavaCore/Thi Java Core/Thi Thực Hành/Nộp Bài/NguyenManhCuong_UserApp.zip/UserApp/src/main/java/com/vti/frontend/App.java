package com.vti.frontend;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.vti.backend.presentationlayer.UserController;
import com.vti.backend.utils.JDBCUtils;
import com.vti.backend.utils.ScannerUtils;
import com.vti.entity.User;

/**
 * Hello world!
 *
 */
public class App {

	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		Connection connection = JDBCUtils.getConnection();
		if (connection != null) {
			displayScreen();
			int inputOption = ScannerUtils.inputInt();
			switch (inputOption) {
			case 1:
				registerManager();
				break;
			case 2:
				registerEmp();
				break;
			case 3:
				login();
				break;
			case 4:
				System.exit(0);
				break;					
			default:
				break;
			}
		}
	}

	private static void login() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		UserController userController = new UserController();
		while (true) {
			System.out.print("Nhập email: ");
			String email = ScannerUtils.inputEmail();

			System.out.print("Nhập password: ");
			String password = ScannerUtils.inputPassword();

			User user = userController.login(email, password);

			if (user != null) {
				System.out.printf("Xin chào %s \n \n \n",
						user.getFullName() + " " + user.getRole());
				return;
			} else {
				System.err.println("Nhập Email/Password ko đúng! Mời đăng nhập lại!");
			}
		}		
	}

	private static void registerManager() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		UserController userController = new UserController();
		System.out.println("Mời nhập tên");
		String fullName = ScannerUtils.inputString("Tên ko được để trống");
		System.out.println("Mời nhập email");
		String email = "";
		while (true) {
			email = ScannerUtils.inputEmail();// kiểm tra đúng định dạng email hay chưa
			boolean resultExistsEmail = userController.isExistsEmail(email); // kiểm tra email có bị trùng hay ko
			if (resultExistsEmail) {
				System.err.printf("\nEmail %s đã tồn tại, mời nhập email khác: ", email);
			} else {
				break;
			}
		}
		System.out.print("Mời nhập password: ");
		String password = ScannerUtils.inputPassword();
		System.out.println("Mời nhập số năm kinh nghiệm");
		int expInYear = ScannerUtils.inputInt("Số năm ko đc để trống");
		System.out.println("Mời nhập project Id");
		int projectId = ScannerUtils.inputInt("Project Id ko đc để trống");
		boolean check = userController.registerManager(fullName, email, password, expInYear, projectId);
		if (check) {
			System.out.println("Tạo mới Manager thành công");
		} else {
			System.out.println("Tạo Manager không thành công");
		}
	}

	private static void registerEmp() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		UserController userController = new UserController();
		System.out.println("Mời nhập tên");
		String fullName = ScannerUtils.inputString("Tên ko được để trống");
		System.out.println("Mời nhập email");
		String email = "";
		while (true) {
			email = ScannerUtils.inputEmail();// kiểm tra đúng định dạng email hay chưa
			boolean resultExistsEmail = userController.isExistsEmail(email); // kiểm tra email có bị trùng hay ko
			if (resultExistsEmail) {
				System.err.printf("\nEmail %s đã tồn tại, mời nhập email khác: ", email);
			} else {
				break;
			}
		}
		System.out.print("Mời nhập password: ");
		String password = ScannerUtils.inputPassword();
		System.out.println("Mời nhập kĩ năng chuyên môn");
		String proSkill = ScannerUtils.inputString("Kĩ năng chuyên môn");
		System.out.println("Mời nhập project Id");
		int projectId = ScannerUtils.inputInt("Project Id ko đc để trống");
		boolean check = userController.registerEmp(fullName, email, password, proSkill, projectId);
		if (check) {
			System.out.println("Tạo mới Employee thành công");
		} else {
			System.out.println("Tạo Employee không thành công");
		}
	}

	private static void displayScreen() {
		// TODO Auto-generated method stub
		System.out.println("****Menu: Quản lý User*******");
		System.out.println("1: Register Manager");
		System.out.println("2: Register Employee");
		System.out.println("3: Login");
		System.out.println("4: Exit");
		System.out.println("======Mời bạn chọn chức năng======");
	}
}
