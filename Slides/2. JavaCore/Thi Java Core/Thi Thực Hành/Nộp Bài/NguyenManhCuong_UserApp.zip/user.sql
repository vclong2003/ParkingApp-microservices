DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `UserId` int primary key auto_increment,
  `FullName` varchar(255),
  `Email` varchar(255),
  `Password` varchar(255),
  `Role` varchar(255),
  `ExpInYear` int,
  `ProjectId` int,
  `ProSkill` varchar(255)
);
