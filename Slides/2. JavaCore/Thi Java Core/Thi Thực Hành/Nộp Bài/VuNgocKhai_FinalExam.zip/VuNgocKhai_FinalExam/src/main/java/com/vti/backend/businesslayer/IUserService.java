package com.vti.backend.businesslayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.entity.Employee;
import com.vti.entity.Employee.ProSkill;
import com.vti.entity.Manager;

public interface IUserService {
	public boolean CheckLogin(String email, String password) throws SQLException;
	public boolean insertEmployee(String fullName, String email, String password, int projectId, ProSkill proSkill) throws SQLException;
	public  List<Employee> ListEmployee(String projectId) throws SQLException;
	public  List<Manager> ListManager() throws SQLException;
}
