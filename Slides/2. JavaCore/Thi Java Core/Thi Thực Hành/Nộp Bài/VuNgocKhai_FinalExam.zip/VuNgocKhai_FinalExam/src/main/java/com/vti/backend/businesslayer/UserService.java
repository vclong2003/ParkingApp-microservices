package com.vti.backend.businesslayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.backend.datalayer.UserRepository;
import com.vti.entity.Employee;
import com.vti.entity.Employee.ProSkill;
import com.vti.entity.Manager;
import com.vti.backend.datalayer.IUserRepository;

public class UserService implements IUserService {
	private IUserRepository usersRepository;
	public UserService() {
		usersRepository = new UserRepository();
	}
	@Override
	public boolean CheckLogin(String email, String password) throws SQLException {
		// TODO Auto-generated method stub
		return usersRepository.CheckLogin(email, password);
	}
	@Override
	public boolean insertEmployee(String fullName, String email, String password, int projectId, ProSkill proSkill) 
			throws  SQLException {
		// TODO Auto-generated method stub
		return usersRepository.insertEmployee(fullName, email, password, projectId, proSkill);
	}
	@Override
	public List<Employee> ListEmployee(String projectId) throws SQLException {
		// TODO Auto-generated method stub
		return usersRepository.ListEmployee(projectId);
	}
	
	public  List<Manager> ListManager() throws SQLException {
		return usersRepository.ListManager();
	}
	
	
	}
	
	

