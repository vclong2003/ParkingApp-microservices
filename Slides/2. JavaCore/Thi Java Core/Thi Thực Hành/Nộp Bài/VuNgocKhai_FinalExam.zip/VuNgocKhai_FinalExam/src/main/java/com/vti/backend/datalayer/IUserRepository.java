package com.vti.backend.datalayer;

import java.sql.SQLException;
import java.util.List;

import com.vti.entity.Employee;
import com.vti.entity.Employee.ProSkill;
import com.vti.entity.Manager;
import com.vti.entity.User;

public interface IUserRepository {
	public boolean CheckLogin(String email, String password) throws SQLException;
	public boolean insertEmployee(String fullName, String email, String password, int projectId, ProSkill proSkill) throws SQLException;
	public  List<Employee> ListEmployee(String projectId) throws SQLException;
	public  List<Manager> ListManager() throws SQLException;
}
