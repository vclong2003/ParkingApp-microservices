package com.vti.backend.datalayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.vti.entity.Users;
import com.vti.entity.Employee;
import com.vti.entity.Employee.ProSkill;
import com.vti.entity.Manager;
import com.vti.entity.User;
import com.vti.entity.User.Role;
import com.vti.utils.JDBCUtils;

public class UserRepository implements IUserRepository {
	private JDBCUtils jdbcUtils;

	public UserRepository() {
		jdbcUtils = new JDBCUtils();
	}
	@Override
	public boolean CheckLogin(String email, String password) throws SQLException {
		Connection con = JDBCUtils.getConnection();
		String selectQuery = "SELECT * FROM user WHERE email = ? AND password = ?";
        try {
            PreparedStatement selectStatement = con.prepareStatement(selectQuery);
            // Kiểm tra xem dữ liệu đã tồn tại hay chưa
            selectStatement.setString(1, email);
            selectStatement.setString(2, password);
            ResultSet resultSet = selectStatement.executeQuery();
            // Nếu dữ liệu chưa tồn tại
            if (resultSet.next()) {
              JDBCUtils.closeConnection(con, resultSet, selectStatement, null);
              return true;
            } else {
            	JDBCUtils.closeConnection(con, resultSet, selectStatement, null);
            	System.out.println("Thông tin tài khoản hoặc mật khẩu không chính xác!");
                return false;
            }
        } catch (SQLException e) {
            // Xử lý lỗi SQL
            e.printStackTrace();
            return false;
        }
	}
	
	@Override
	public boolean insertEmployee(String fullName, String email, String password, int projectId, ProSkill proSkill) throws SQLException {
			// Step 1: get connection
			Connection con = JDBCUtils.getConnection();

			// Step 2: Create a statement obiect
			try {
			String sql = "INSERT INTO user (full_name, email, `password`, project_id, pro_skill, `role`)" +
					" VALUES (?, ?, ?, ?, ?, 'Employee');";
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setString(1, fullName);
			statement.setString(2, email);
			statement.setString(3, password);
			statement.setInt(4, projectId);
			statement.setString(5, proSkill.toString());
			// Step 3: Execute SQL query
			int rs = statement.executeUpdate();
			if(rs>=0) {
				JDBCUtils.closeConnection(con, null, statement, null);
				return true;
			}else {
				JDBCUtils.closeConnection(con, null, statement, null);
				
				return false;
			}
			} catch (SQLException e) {
	            // Xử lý lỗi SQL
	            e.printStackTrace();
	            return false;
	        }
	}
	
	@Override
	public  List<Employee> ListEmployee(String projectId) throws SQLException {
		List<Employee> Luser = new ArrayList<Employee>();
		Connection con = JDBCUtils.getConnection();
		String selectQuery = "SELECT * FROM user where project_id=? and role = ?";
        try {
            PreparedStatement selectStatement = con.prepareStatement(selectQuery);
            selectStatement.setString(1, projectId);
            selectStatement.setString(2, "Employee");
            ResultSet resultSet = selectStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                // Trích xuất dữ liệu từ ResultSet và tạo một đối tượng User
                int id = resultSet.getInt("id");
                String full_name = resultSet.getString("full_name");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");
                int project_id = resultSet.getInt("project_id");
                String roleString = resultSet.getString("role");
                Role role = Role.valueOf(roleString);
                String proSkill1 = resultSet.getString("pro_skill");
                ProSkill proSkill = ProSkill.valueOf(proSkill1);
                Employee employee = new Employee( id, full_name, email, password, role, project_id, proSkill);   	
                Luser.add(employee);
                i++;
            } return Luser;
        } catch (SQLException e) {
            // Xử lý lỗi SQL
            e.printStackTrace();
            return null ;
        }
	}
	
	@Override
	public  List<Manager> ListManager() throws SQLException {
		List<Manager> Luser = new ArrayList<Manager>();
		Connection con = JDBCUtils.getConnection();
		String selectQuery = "SELECT * FROM user where role = ?";
        try {
            PreparedStatement selectStatement = con.prepareStatement(selectQuery);
            selectStatement.setString(1, "Manager");
            ResultSet resultSet = selectStatement.executeQuery();
            int i = 0;
            while (resultSet.next()) {
                // Trích xuất dữ liệu từ ResultSet và tạo một đối tượng User
                int id = resultSet.getInt("id");
                String full_name = resultSet.getString("full_name");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");
                int project_id = resultSet.getInt("project_id");
                String roleString = resultSet.getString("role");
                Role role = Role.valueOf(roleString);
                int expinyear = resultSet.getInt("exp_in_year");
                Manager manager = new Manager( id, full_name, email, password, role, expinyear, project_id);   	
                Luser.add(manager);
                i++;
            } return Luser;
        } catch (SQLException e) {
            // Xử lý lỗi SQL
            e.printStackTrace();
            return null ;
        }
	}
}

