package com.vti.backend.presentationlayer;

import com.vti.backend.businesslayer.UserService;
import com.vti.entity.Employee;
import com.vti.entity.Employee.ProSkill;
import com.vti.entity.Manager;

import java.sql.SQLException;
import java.util.List;

import com.vti.backend.businesslayer.IUserService;

public class UserController {
	private IUserService userService;
	public UserController() {
		userService = new UserService();
	}	
	public boolean CheckLogin(String email, String password) throws SQLException {
		return userService.CheckLogin(email, password);
	}
	
	public boolean insertEmployee(String fullName, String email, String password, int projectId, ProSkill proSkill) 
			throws  SQLException{
		return userService.insertEmployee(fullName, email, password, projectId, proSkill);
	}
	
	public  List<Employee> ListEmployee(String projectId) throws SQLException {
		return userService.ListEmployee(projectId);
	}
	
	public  List<Manager> ListManager() throws SQLException {
		return userService.ListManager();
	}
}
