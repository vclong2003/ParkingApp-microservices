package com.vti.entity;

public class Employee extends User{
	private int projectId;
	private ProSkill proSkill;
	
	public enum ProSkill {
		dev, test, java, sql;
	}

	public Employee(int id, String fullName, String email, String password, Role role, int projectId, ProSkill proSkill) {
		super(id, fullName, email, password, role);
		this.projectId = projectId;
		this.proSkill = proSkill;
	}
	
	public Employee(int id, String fullName, String email, String password, Role role, int projectId) {
		super(id, fullName, email, password, role);
		this.projectId = projectId;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public ProSkill getProSkill() {
		return proSkill;
	}

	public void setProSkill(ProSkill proSkill) {
		this.proSkill = proSkill;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Empoyee [Id:"  + getId() + " Fullname: " + super.getFullName() + " Email: " + super.getEmail() + " Password: " + super.getPassword() + " Role: " + super.getRole()+ " ProjectID: "+ getProjectId()+ " ProSkill: " + getProSkill() +"]";	
		}
	}


