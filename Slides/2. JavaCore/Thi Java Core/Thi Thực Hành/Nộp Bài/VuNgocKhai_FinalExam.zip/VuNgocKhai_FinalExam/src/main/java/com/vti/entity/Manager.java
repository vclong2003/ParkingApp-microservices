package com.vti.entity;

public class Manager extends User {
	private int expInYear;
	private int projectId;
	
	public Manager(int id, String fullName, String email, String password, Role role, int expInYear, int projectId) {
		super(id, fullName, email, password, role);
		this.expInYear = expInYear;
		this.projectId = projectId;
	}

	public int getExpInYear() {
		return expInYear;
	}

	public void setExpInYear(int expInYear) {
		this.expInYear = expInYear;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Manager [Id: " + getId() + " Fullname: " + super.getFullName() + " Email: " + super.getEmail() + " Password: " + super.getPassword() + " Role: " + super.getRole()+ " ProjectID: "+ getProjectId() + " ExpInYear: " + getExpInYear() + "]";
	}
	
	
}
