package com.vti.frontend;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import com.vti.backend.presentationlayer.UserController;
import com.vti.entity.Users;
import com.vti.entity.Employee;
import com.vti.entity.Employee.ProSkill;
import com.vti.entity.Manager;
import com.vti.utils.DateUtils;
import com.vti.utils.JDBCUtils;
import com.vti.utils.ScannerUtils;


import java.sql.CallableStatement;


public class Program {

	public static void main(String[] args) throws FileNotFoundException, IOException, SQLException {	
				UserController userController = new UserController();
				Scanner scanner = new Scanner(System.in);
				Menu();
				while(true) {
					System.out.print("Mời bạn chọn chức năng: ");
					int choice = 0;
					choice = ScannerUtils.inputInt();
					switch(choice) {
					case 1:
						System.out.print("Email: " );
						String email = ScannerUtils.inputEmail();
						System.out.print("Password: ");
						String password = ScannerUtils.inputPass("Mật khẩu từ 6 đến 12 ký tự: ");
						if(userController.CheckLogin(email, password)) {
							System.out.println("Login successfully");
						}
						break;
					case 2:
						System.out.print("Fullname: " );
						String fullname = ScannerUtils.inputString("Vui lòng nhập lại!");
						System.out.print("Email: " );
						String email1 = ScannerUtils.inputEmail();
						System.out.print("Mật khẩu: ");
						String password1 = ScannerUtils.inputPass("Mật khẩu từ 6 đến 12 ký tự: ");
						System.out.print("Project ID: ");
						int projectId = ScannerUtils.inputInt("Vui long nhập lại! ");
						System.out.print("proSkill: ");
						ProSkill proSkill = getproSkill();
							try {
								if(userController.insertEmployee(fullname, email1, password1, projectId, proSkill)) {
								//boolean ins = userController.registerUsers(user_name, password, email, phone_number, currentDate);
								System.out.println("Enter successfully");
								Menu();
								} else {
									System.out.println("Enter failed"); 
								}
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								System.out.println("Enter failed");
							}
						
						break;
					case 3:
						ListEmployee();
		                break;
					case 4:
						ListManager();
		                break;
					default:
						System.out.println("Bạn chỉ được chọn các số từ 1 đến 4");
						break;
					}
				}
			}	
			public static void Menu() {
				String leftAlignFormat = "| %-72s |%n";
				System.out.format("+--------------------------------------------------------------------------+%n");
				System.out.format("|                                    MENU                                  |%n");
				System.out.format("+--------------------------------------------------------------------------+%n");
				System.out.format(leftAlignFormat,"1. Login");
				System.out.format(leftAlignFormat,"2. Enter Employee");
				System.out.format(leftAlignFormat,"3. List Employee");
				System.out.format(leftAlignFormat,"4: List Manager");
				System.out.format("+--------------------------------------------------------------------------+%n");
			}
			
			
			private static ProSkill getproSkill() {

				while (true) {
					System.out.println("------MỜI BẠN CHỌN PROSKILL------");
					String leftAlignFormat = "| %-72s |%n";
					System.out.format("+--------------------------------------------------------------------------+%n");
					System.out.format("|                        Choose please                                     |%n");
					System.out.format("+--------------------------------------------------------------------------+%n");
					System.out.format(leftAlignFormat, "1. Dev");
					System.out.format(leftAlignFormat, "2. Test");
					System.out.format(leftAlignFormat, "3. Java");
					System.out.format(leftAlignFormat, "4. Sql");
					System.out.format("+--------------------------------------------------------------------------+%n");
					switch (ScannerUtils.inputInt("Chọn 1-4")) {
					case 1:
						return ProSkill.dev;
					case 2:
						return ProSkill.test;
					case 3:
						return ProSkill.java;
					case 4:
						return ProSkill.sql;
					default:
						System.out.println("Nhập lại:");
						break;

					}
				}
			}
			
			private static void ListEmployee() throws SQLException {
				UserController userController = new UserController();
				System.out.print("Nhập vào projectID: ");
				String input = ScannerUtils.inputString("Không được để trống");
				System.out.println("Id\tFullname\tEmail\t\tPassword\tRole\t\tProjectID\tProSkill\n");
				List<Employee> Luser = userController.ListEmployee(input);
				for(Employee user: Luser) {
					System.out.println(user.getId()+"\t"+ user.getFullName() +"\t\t"+ user.getEmail()+"\t"+ user.getPassword()+"\t\t"+ user.getRole()+"\t"+ user.getProjectId()+"\t\t"+ user.getProSkill());
				}
			}
			
			private static void ListManager() throws SQLException {
				UserController userController = new UserController();
				List<Manager> Luser1 = userController.ListManager();
				System.out.println("Id\tFullname\tEmail\t\tPassword\tRole\t\tProjectID\tExpInYear\n");
				for(Manager user: Luser1) {
					System.out.println(user.getId()+"\t"+ user.getFullName() +"\t\t"+ user.getEmail()+"\t"+ user.getPassword()+"\t\t"+ user.getRole()+"\t\t"+ user.getProjectId()+"\t\t"+ user.getExpInYear());
				}
			}
			

			
}
			


