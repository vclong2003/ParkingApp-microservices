package com.vti.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateUtils {
	
	public static void main(String[] args) {
		 LocalDateTime now = LocalDateTime.now();
	        
	        // Gọi hàm để chuyển đổi và in ra ngày tháng năm giờ phút giây
	        String formattedDateTime = formatDateTime(now, "dd-MM-yyyy HH:mm:ss");
	        System.out.println("Ngày tháng năm giờ phút giây: " + formattedDateTime);
	}
	
	public static LocalDate getCurrentDate() {
        return LocalDate.now();
    }
	
	public static String formatDateTime(LocalDateTime dateTime, String pattern) {    
        // Gọi hàm để chuyển đổi và in ra ngày tháng năm giờ phút giây 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return dateTime.format(formatter);
    }
}
