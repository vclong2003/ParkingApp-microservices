package com.vti.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtils {
	public static final String FILE_EXISTS = "Error! File is Exist!";
	public static final String FILE_NOT_EXISTS = "Error! File is not Exist!";
	public static final String PATH_NOT_EXISTS = "Error! Path is Exist!";
	public static final String FOLDER = "Path is Folder!";
	public static final String FILE = "Path is File!";
	public static final String FOLDER_EXISTS = "Error! Folder is Exist!";
	public static final String FOLDER_NOT_EXISTS = "Error! Folder is not Exist!";
	public static final String CREATE_FILE_SUCCESS = "Create file success!";
	public static final String CREATE_FILE_FAIL = "Create file fail!";
	public static final String DELETE_FILE_SUCCESS = "Delete file success!";
	public static final String DELETE_FILE_FAIL = "Delete file fail!";
	
	
	
	// Check file is exists
	public static boolean isFileExist(String pathFile) {
		return new File(pathFile).exists();
		}
	
	// Create file
	public static void createFile (String pathFile) throws IOException {
		if(isFileExist(pathFile)) {
			throw new IOException(FILE_EXISTS);
		} else {
			System.out.println(new File(pathFile).createNewFile() ? CREATE_FILE_SUCCESS: CREATE_FILE_FAIL);
		}
	}
	
	public static void createFile (String path, String fileName) throws IOException {
		String pathFile = path + "//" + fileName;
		if(isFileExist(pathFile)) {
			throw new IOException(FILE_EXISTS);
		} else {
			System.out.println(new File(pathFile).createNewFile() ? CREATE_FILE_SUCCESS: CREATE_FILE_FAIL);
		}
	}
	
	//Check path is File or Folder
	public static void isFiOrFo (String pathFile) throws IOException {
		if(!isFileExist(pathFile)) {
			throw new IOException(PATH_NOT_EXISTS);
		} else {
			System.out.println(new File(pathFile).isDirectory() ? FOLDER: FILE);
		}
	}
	
	//Delete file
	public static void deleteFile(String pathFile) throws IOException {
        File file = new File(pathFile);
        if (!isFileExist(pathFile)) {
            throw new IOException(FILE_NOT_EXISTS);
        } else {
            System.out.println(file.delete() ? DELETE_FILE_SUCCESS: DELETE_FILE_FAIL); 
        }
    }
	
	//Get all file of folder
	public static void getAllFile(String pathFile) throws IOException {
        File file = new File(pathFile);
        if (!isFileExist(pathFile)) {
            throw new IOException(FOLDER_NOT_EXISTS);
        } else {
        	for(String fileName: file.list()) {
        		System.out.println("Tất cả các file trong thư mục"); 
        		System.out.println(fileName);
        	}
        }
    }
	
	//Copy file
	public static void copyFile(String sourcePath, String destinationPath) throws IOException {
        Path source = Paths.get(sourcePath);
        Path destination = Paths.get(destinationPath);
        
        /* Tương tự tạo đường dẫn 
         * File file = new File("/path/to/file.txt");
         * Path path = file.toPath();
         */
        
        // Sao chép từ sourcePath sang destina
        Files.copy(source, destination);
        //Files.move(source, destination); Di chuyển file
        
        /*
        * File oldFile = new File(oldFilePath);
        * File newFile = new File(newFilePath);
        * oldFile.renameTo(newFile
        */
    }
	
	/* Tạo thư mục 
	 * String directoryPath = "/path/to/newdirectory";
     * File directory = new File(directoryPath);
     * directory.mkdirs()
	 */
	
}
