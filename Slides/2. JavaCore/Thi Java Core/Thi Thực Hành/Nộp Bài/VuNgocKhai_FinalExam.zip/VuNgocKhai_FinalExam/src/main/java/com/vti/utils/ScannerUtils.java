package com.vti.utils;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScannerUtils {

	private static Scanner scanner = new Scanner(System.in);

	public static int inputId(String msg) {
		while (true) {
			System.out.println(msg);
			int id = inputInt("Id là một số nguyên, vui lòng nhập lại!");
			if (id > 0) {
				return id;
			}
			// else
			System.out.println("Id phải là số nguyên lớn hơn 0, vui lòng nhập lại!");
		}
	}

	public static String inputName(String msg) {
		System.out.println(msg);
		return inputString("Vui lòng nhập lại tên: ");
	}

	public static int inputInt() {
		return inputInt("Nhập vào một số nguyên, vui lòng nhập lại: ");
	}

	public static int inputInt(String errorMessage) {
		while (true) {
			try {
				return Integer.parseInt(scanner.nextLine().trim());
			} catch (Exception e) {
				System.err.println(errorMessage);
			}
		}
	}

	public static float inputFloat(String errorMessage) {
		while (true) {
			try {
				return Float.parseFloat(scanner.nextLine().trim());
			} catch (Exception e) {
				System.err.println(errorMessage);
			}
		}
	}

	public static double inputDouble(String errorMessage) {
		while (true) {
			try {
				return Double.parseDouble(scanner.nextLine().trim());
			} catch (Exception e) {
				System.err.println(errorMessage);
			}
		}
	}

	public static String inputString(String errorMessage) {
		while (true) {
			String input = scanner.nextLine().trim();
			if (!input.isEmpty()) {
				return input;
			} else {
				System.err.println(errorMessage);
			}
		}
	}
	
	public static String inputPass(String errorMessage) {
		while (true) {
			String input = scanner.nextLine().trim();
			if (!input.isEmpty() && input.length()>=6 && input.length() <=12) {
				return input;
			} else {
				System.err.println(errorMessage);
			}
		}
	}
	

	public static int inputAge() {
		while (true) {
			int age = inputInt("Nhập sai! Tuổi phải là số nguyên, vui lòng nhập lại tuổi: ");

			if (age <= 0) {
				System.err.println("Nhập sai! Tuổi phải lớn hơn 0, vui lòng nhập lại: ");

			} else {
				return age;
			}
		}
	}

	public static int inputAgeGreaterThan18() {
		while (true) {
			int age = inputAge();

			if (age >= 18) {
				return age;

			} else {
				System.out.println("Nhập sai! Tuổi phải lớn hơn 18, vui lòng nhập lại: ");
			}
		}
	}
	
	public static String inputPhone() {
		while (true) {
			String input = scanner.nextLine().trim();
			if (isValidPhoneNumber(input)) {
	            return input;
	        } else {
	            System.err.println("Số điện thoại không hợp lệ.");
	        }
		}
	}
	
	public static boolean isValidPhoneNumber(String phoneNumber) {
		String phoneRegex = "^\\+?(84|0)[- ]?(\\d{4})[- ]?(\\d{3})[- ]?(\\d{1,2})$";
        Pattern pattern = Pattern.compile(phoneRegex);
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
	}
	
	public static String inputEmail() {
		while (true) {
			String input = scanner.nextLine().trim();
			if (isValidEmail(input)) {
	            return input;
	        } else {
	            System.err.println("Địa chỉ email không hợp lệ.");
	        }
		}
	}
	
	public static boolean isValidEmail(String email) {
        // Biểu thức chính quy để kiểm tra định dạng email
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

        // Tạo Pattern object
        Pattern pattern = Pattern.compile(emailRegex);

        // Tạo matcher object
        Matcher matcher = pattern.matcher(email);

        return matcher.matches();
    }
	
	public static void closeProgram() {
		System.out.println("Đã thoát chương trình.");
		System.exit(0);
	}

}
