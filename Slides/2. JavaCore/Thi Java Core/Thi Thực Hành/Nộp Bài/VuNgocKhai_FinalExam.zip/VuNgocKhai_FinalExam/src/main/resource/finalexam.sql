CREATE DATABASE IF NOT EXISTS finalexam;
use finalexam;
CREATE TABLE user(
	id int primary key auto_increment,
    full_name varchar(50),
    email varchar(50),
    `password` varchar(50),
    exp_in_year int,
    project_id int,
    pro_skill varchar(50),
    `role` varchar(50) 
);

INSERT INTO 
    `user` (full_name, email, `password`, exp_in_year, project_id, pro_skill, `role`) 
VALUES 
    ('Vu A', '123@gmail.com', '123456', null, 333, 'dev', 'Employee'),
    ('Nguyen C', '127@gmail.com', '123456', null, 222, 'java', 'Employee'),
    ('Tran D', '124@gmail.com', '123456', 7, 333, null, 'Manager'),
    ('Bui A', 'twet@gmail.com', '123456', null, 111, 'test', 'Employee'),
    ('Vu QC', 'ct2@gmail.com', '123456', null, 212, 'java', 'Employee'),
    ('Doan N', 'mtm@gmail.com', '123456', 4, 212, null, 'Manager'),
    ('Vu B', 'asj@gmail.com', '123456', null, 333, 'test', 'Employee');