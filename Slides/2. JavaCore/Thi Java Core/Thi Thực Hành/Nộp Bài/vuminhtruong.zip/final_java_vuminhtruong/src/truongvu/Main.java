package truongvu;

import truongvu.frontend.Function;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Function function = new Function();

        System.out.println("Enter function:\n 1. Get Employee By Project ID  \n 2. Get All Manager \n 3.Login");

        int n = scanner.nextInt();
        scanner.nextLine();

        switch (n) {
            case 1:
                System.out.println("Enter Project ID:");
                int id = scanner.nextInt();
                function.getAllEmployeesByProjectId(id);
                break;
            case 2:
                function.getAllManagers();
                break;
            case 3:
                function.login();
                break;
        }

    }
}