package truongvu.backend.business;

import truongvu.backend.data.IUserRepository;
import truongvu.entity.Employee;
import truongvu.entity.Manager;
import truongvu.entity.User;

import java.sql.SQLException;
import java.util.List;

public interface IUserService {
    User login(String email, String password) throws SQLException, ClassNotFoundException;
    List<Employee> findAllEmployeeByProjectId(int id) throws SQLException;
    List<Manager> findAllManger() throws SQLException;
}
