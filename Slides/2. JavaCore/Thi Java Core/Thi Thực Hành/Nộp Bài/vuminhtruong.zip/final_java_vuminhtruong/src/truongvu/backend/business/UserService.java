package truongvu.backend.business;

import truongvu.backend.data.IUserRepository;
import truongvu.backend.data.UserRepository;
import truongvu.entity.Employee;
import truongvu.entity.Manager;
import truongvu.entity.User;

import java.sql.SQLException;
import java.util.List;

public class UserService implements IUserService{
    private IUserRepository userRepository;

    public UserService() {
        userRepository = new UserRepository();
    }

    @Override
    public User login(String email, String password) throws SQLException, ClassNotFoundException {
        return userRepository.login(email, password);
    }

    @Override
    public List<Employee> findAllEmployeeByProjectId(int id) throws SQLException {
        return userRepository.findAllEmployeeByProjectId(id);
    }

    @Override
    public List<Manager> findAllManger() throws SQLException {
        return userRepository.findAllManger();
    }
}
