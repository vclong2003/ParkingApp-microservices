package truongvu.backend.data;

import truongvu.entity.*;
import truongvu.utils.JdbcConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserRepository implements IUserRepository{
    private JdbcConnection jdbcConnection;
    @Override
    public User login(String email, String password) throws SQLException, ClassNotFoundException {
        try {
            Connection connection = jdbcConnection.getConnection();

            String sql = "select * from user where email = ? and `password` = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, password);

            // Step 3: Execute SQL query
            ResultSet resultSet = statement.executeQuery();

            // Step 4: Handling Result Set
            if (resultSet.next()) {
                int id = resultSet.getInt(1);
                String fullName = resultSet.getString(2);
                int project_id = resultSet.getInt(7);
                String role = resultSet.getString(8);
                Role rol = role.equals("Manager") ? Role.Manager : Role.Employee;

                if (role.equals("Manger")) {
                    int expInYear = resultSet.getInt(5);

                    return new Manager(id, fullName, email, password, expInYear, project_id, rol);
                } else {
                    ProSkill proSkill = ProSkill.valueOf(resultSet.getString(6));

                    return new Employee(id, fullName, email, password, project_id, proSkill, rol);
                }
            } else {
                return null;
            }
        } finally {
            jdbcConnection.disconnect();
        }
    }

    @Override
    public List<Employee> findAllEmployeeByProjectId(int id) throws SQLException {
        List<Employee> list = new ArrayList<>();
        try {
            Connection connection = jdbcConnection.getConnection();

            String sql = "select * from user where role = 'employee' and project_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Employee employee = new Employee();
                employee.setId(resultSet.getInt(1));
                employee.setFullName(resultSet.getString(2));
                employee.setProjectId(resultSet.getInt(7));
                employee.setRole(Role.Employee);
                employee.setProSkill(ProSkill.valueOf(resultSet.getString(6)));


                list.add(employee);
            }
            return list;
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            jdbcConnection.disconnect();
        }
    }

    @Override
    public List<Manager> findAllManger() throws SQLException {
        List<Manager> list = new ArrayList<>();
        try {
            Connection connection = jdbcConnection.getConnection();

            String sql = "select * from user where role = 'manager'";
            PreparedStatement statement = connection.prepareStatement(sql);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                Manager manager = new Manager();
                manager.setId(resultSet.getInt(1));
                manager.setFullName(resultSet.getString(2));
                manager.setProjectId(resultSet.getInt(7));
                manager.setRole(Role.Manager);
                manager.setExpInYear(resultSet.getInt(5));

                list.add(manager);
            }
            return list;
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            jdbcConnection.disconnect();
        }
    }
}
