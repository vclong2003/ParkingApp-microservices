package truongvu.backend.presentation;

import truongvu.backend.business.IUserService;
import truongvu.backend.business.UserService;
import truongvu.entity.Employee;
import truongvu.entity.Manager;
import truongvu.entity.User;

import java.sql.SQLException;
import java.util.List;

public class UserController {
    private IUserService userService;

    public UserController() {
        userService = new UserService();
    }

    public User login(String email, String password) throws SQLException, ClassNotFoundException {
        return userService.login(email, password);
    }

    public List<Employee> findAllEmployeeByProjectId(int id) throws SQLException {
        return userService.findAllEmployeeByProjectId(id);
    }

    public List<Manager> findAllManager() throws SQLException {
        return userService.findAllManger();
    }
}
