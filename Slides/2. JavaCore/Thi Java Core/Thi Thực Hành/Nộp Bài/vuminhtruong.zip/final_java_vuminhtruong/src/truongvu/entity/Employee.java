package truongvu.entity;

public class Employee extends User{
    private int projectId;
    private ProSkill proSkill;

    public Employee() {
    }

    public Employee(int id, String fullName, String email, String password, int projectId, ProSkill proSkill, Role role) {
        super(id, fullName, email, password, role);
        this.projectId = projectId;
        this.proSkill = proSkill;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public ProSkill getProSkill() {
        return proSkill;
    }

    public void setProSkill(ProSkill proSkill) {
        this.proSkill = proSkill;
    }
}
