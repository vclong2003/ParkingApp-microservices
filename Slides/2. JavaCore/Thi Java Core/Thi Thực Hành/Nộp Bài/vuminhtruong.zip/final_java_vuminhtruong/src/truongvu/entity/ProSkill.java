package truongvu.entity;

public enum ProSkill {
    DEV, TEST, JAVA, SQL, BA
}
