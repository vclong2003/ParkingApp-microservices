package truongvu.entity;

public enum Role {
    Manager, Employee
}
