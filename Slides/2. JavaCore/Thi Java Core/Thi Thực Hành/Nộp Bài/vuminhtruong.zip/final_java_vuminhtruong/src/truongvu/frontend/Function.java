package truongvu.frontend;

import truongvu.backend.presentation.UserController;
import truongvu.entity.Employee;
import truongvu.entity.User;
import truongvu.utils.PrintTable;
import truongvu.utils.Validate;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Function {
    private UserController userController;

    public Function() {
        userController = new UserController();
    }

    Scanner scanner = new Scanner(System.in);

    public void login() throws ClassNotFoundException, SQLException {
        while (true) {
            System.out.print("Enter your email: ");
            String email = Validate.inputEmail();

            System.out.print("Enter your password: ");
            String password = Validate.inputPassword();

            User user = userController.login(email, password);

            if (user != null) {
                System.out.printf("Welcome %s,\n ---- Role: (%s) ---- \n \n \n",
                        user.getFullName(), user.getRole());
                return;
            } else {
                System.err.println("Email or Password is not correct");
            }
        }
    }

    public void getAllEmployeesByProjectId(int id) throws SQLException {
        PrintTable.printTableEmployee(userController.findAllEmployeeByProjectId(id));
    }

    public void getAllManagers() throws SQLException {
        PrintTable.printTableManager(userController.findAllManager());
    }
}
