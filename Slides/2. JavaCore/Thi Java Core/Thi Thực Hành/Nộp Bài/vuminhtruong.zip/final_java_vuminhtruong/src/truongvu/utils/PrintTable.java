package truongvu.utils;

import truongvu.entity.Employee;
import truongvu.entity.Manager;

import java.util.List;

public class PrintTable {
    public static void printTableManager(List<Manager> managers) {
        String header = String.format("%-5s %-20s %-30s %-10s %-10s %-10s", "ID", "Full Name", "Email", "Exp. in Year", "Project ID", "Role");
        System.out.println(header);
        System.out.println(new String(new char[header.length()]).replace('\0', '-'));

        for (Manager manager : managers) {
            String row = String.format("%-5s %-20s %-30s %-10s %-10s %-10s",
                    manager.getId(),
                    manager.getFullName(),
                    manager.getEmail(),
                    manager.getExpInYear(),
                    manager.getProjectId(),
                    manager.getRole());
            System.out.println(row);
        }
    }

    public static void printTableEmployee(List<Employee> employees) {
        String header = String.format("%-5s %-20s %-30s %-10s %-10s %-15s %-10s",
                "ID", "Full Name", "Email", "Project ID", "Pro Skill", "Role");
        System.out.println(header);
        System.out.println(new String(new char[header.length()]).replace('\0', '-'));

        for (Employee employee : employees) {
            String row = String.format("%-5s %-20s %-30s %-10s %-10s %-15s %-10s",
                    employee.getId(),
                    employee.getFullName(),
                    employee.getEmail(),
                    employee.getProjectId(),
                    employee.getProSkill(),
                    employee.getRole());
            System.out.println(row);
        }
    }
}
